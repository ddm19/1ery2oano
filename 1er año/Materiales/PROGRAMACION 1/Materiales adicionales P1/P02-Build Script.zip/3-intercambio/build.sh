NOMBRE_PROGRAMA_SIN_EXTENSION="problema3"

if [ -e salidaReal ]
then
  rm salidaReal
  echo "  Borramos el fichero salidaReal de la ejecución anterior"
fi

if [ -e ${NOMBRE_PROGRAMA_SIN_EXTENSION} ]
then
  rm ${NOMBRE_PROGRAMA_SIN_EXTENSION} 
  echo "  Borramos el ejecutable anterior"
fi

echo "Compilando ${NOMBRE_PROGRAMA_SIN_EXTENSION}.cc ..."
g++ -o $NOMBRE_PROGRAMA_SIN_EXTENSION ${NOMBRE_PROGRAMA_SIN_EXTENSION}.cc

echo "Ejecutando ${NOMBRE_PROGRAMA_SIN_EXTENSION} ..."
while read line
do
 echo "  Procesando entrada: $line"
 echo "$line\n" > linea
 ./${NOMBRE_PROGRAMA_SIN_EXTENSION} < linea >> salidaReal
 rm linea
done < entrada

echo "Fin ejecución"

echo "Comprobando el resultado... "
diff salidaEsperada salidaReal
echo "... todo OK!"
