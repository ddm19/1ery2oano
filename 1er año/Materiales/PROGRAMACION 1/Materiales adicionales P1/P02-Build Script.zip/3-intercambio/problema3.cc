//Tipos de datos. Ejercicio 3: Intercambiando valores de variables

#include <iostream>
using namespace std;

int main() {
    int a, b, c, aux;
    
    //leemos los valores a,b,c
    cin >> a;
    cin >> b;
    cin >> c;
    
    //intercambiamos los valores: b,c,a
    aux = b;
    b = c;
    c = a;
    a = aux;
    
    cout << a << " ";
    cout << b << " ";
    cout << c << endl;
    
	return 0;
}
