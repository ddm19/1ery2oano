%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%%%% BASE DE CONOCIMIENTOS DE SISTEMA DE LOGIN DE USUARIOS
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

%%%%%%%%%%%%%%%%%%%%%%%%
%% HECHOS
%%%%%%%%%%%%%%%%%%%%%%%%
usuario('miguel',  '39ef29bfbc298a94fb451b5044c0b5cf54ecde7e').
usuario('maria25', 'c0b306a7fe9d428661c95758c7f3a7b9fa7590d6').
usuario('simon3',  '42361ab7e1654928d49b655f82b0d6c1940d4532').

%%%%%%%%%%%%%%%%%%%%%%%%
%% REGLAS
%%%%%%%%%%%%%%%%%%%%%%%%

%% Eliminar último elemento de una lista
%%
eliminar_ultimo(    [], []).
eliminar_ultimo([_|[]], []).
eliminar_ultimo( LISTA, MENOSULTIMO) :-
      append(MENOSULTIMO, ULTIMO, LISTA)
   ,  length(ULTIMO, 1), !.

%% Escribe por pantalla asteriscos, retornos de carro y borrados 
%%
escribe_asteriscos( _,  13) :- write('\n'), !.
escribe_asteriscos([], 127) :- !.
escribe_asteriscos( _, 127) :- write('\010 \010'), !.
escribe_asteriscos( _,   _) :- write('*').

%% Añade el último carácter leído al password actual
%%
anyade_caracter(PREVIO,   13, PREVIO).
anyade_caracter(    [],  127,     []) :- !.
anyade_caracter(PREVIO,  127, PRMENOSULTIMO) :-
      eliminar_ultimo(PREVIO, PRMENOSULTIMO), !.
anyade_caracter(PREVIO, CODE, ACTUAL) :-
      char_code(CHAR, CODE)
   ,  append(PREVIO, [ CHAR ], ACTUAL).

%% Lee un password mostrando asteriscos por pantalla
%%
leer_password(  13, PREVIO, PREVIO) :- !.
leer_password(CODE, PREVIO, PASS) :-
      anyade_caracter(PREVIO, CODE, ACTUAL)
   ,  get_single_char(NEWCODE)
   ,  escribe_asteriscos(PREVIO, NEWCODE)
   ,  leer_password(NEWCODE, ACTUAL, PASS).
leer_password(PASSWORD) :-
      get_single_char(NEWCODE)
   ,  escribe_asteriscos([], NEWCODE)
   ,  leer_password(NEWCODE, [], LISTPASSWORD)
   ,  atomic_list_concat(LISTPASSWORD, PASSWORD).

%% Comprueba si usuario/password es válido
%%
comprobar_login(USUARIO, PASSWORD) :-
      variant_sha1(PASSWORD, HASH)
   ,  usuario(USUARIO, HASH)
   ,  !.

%% Realiza la operación de login del USUARIO
%%
login(USUARIO) :- 
      maplist(write, [USUARIO, ' teclea tu password: '])
   ,  leer_password(PASSWORD)
   ,  comprobar_login(USUARIO, PASSWORD)
   ,  maplist(write, [  'Password correcto!\n' 
                     ,  'Bienvenido al sistema '
                     ,  USUARIO, '.\n'])
   , !.
login(_) :-
      write('No existe el usuario o password incorrecto\n')
   ,  fail.
