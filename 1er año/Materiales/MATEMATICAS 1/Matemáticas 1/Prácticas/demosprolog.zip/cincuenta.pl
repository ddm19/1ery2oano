%%%%%%%%%%%%%%%%%%%%%%%
% HECHOS
%%%%%%%%%%%%%%%%%%%%%%%

% Cantidad total de preguntas en la base de conocimientos
%
total_preguntas(3).

% Preguntas numeradas, con sus respuestas y el numero de respuesta correcta
%
pregunta(1 
         ,  'Actor protagonista de la pelicula \'La Roca\''
         ,  'Carlos Nuñez'
         ,  'Penelope Cruz'
         ,  'Tom Cruise'
         ,  'Sean Connery'
         ,  '4').
pregunta(2
         ,  'Autor del libro \'La Colmena\''
         ,  'Javier Reverte'
         ,  'Julian Muñoz'
         ,  'Camilo Jose Cela'
         ,  'Buenafuente'
         ,  '3').
pregunta(3
         ,  'Ex-Portero del Real Madrid'
         ,  'Guty'
         ,  'Casillas'
         ,  'Valdes'
         ,  'Ramon Garcia'
         ,  '2').

%%%%%%%%%%%%%%%%%%%%%%%
% REGLAS
%%%%%%%%%%%%%%%%%%%%%%%

% Analizar si una respuesta es o no correcta
%
analizar_respuesta(R, R):-
	   writeln(' Respuesta Correcta! Bravo! ').
analizar_respuesta(A, B):-
      A \= B
   ,  write(' Lo siento. La respuesta correcta era la ')
	,  writeln(B).

% Regla para jugar
%
preguntar:-
	   total_preguntas(X)
	,  P is random(X)+1
	,  pregunta(P, Text, R1, R2, R3, R4, ROK)
	,  writeln(Text)
	,  maplist(write, [  '1. ', R1, '\n'
                     ,  '2. ', R2, '\n'
                     ,  '3. ', R3, '\n'
                     ,  '4. ', R4, '\n'])
	,  write('Pulsa el numero de la respuesta que consideres correcta.\n')
	,  get_single_char(CODE)
	,  char_code(RESP, CODE)
	,  analizar_respuesta(RESP, ROK).