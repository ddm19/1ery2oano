%
% Repite un mismo dibujo Dib (en texto) N veces
%
repiteDib(N,   _):- N < 1.
repiteDib(N, Dib):- 
      N1 is N - 1
   ,  write(Dib)
   ,  repiteDib(N1, Dib).

%
% Alias de repiteDib para dibujar N espacios
%
spcs(N):- repiteDib(N, ' ').

%
% Dibuja el tronco del arbol de forma recursiva
%
dibujaTronco(	   _, Tot) :- Tot < 1.
dibujaTronco(SpcIni, Tot) :- 
      spcs(SpcIni)
   ,  write('||\n')
   ,  Tot1 is Tot - 1
   ,  dibujaTronco(SpcIni, Tot1).

%
% Dibuja el tri�ngulo N del arbol, con SpcIni espacios iniciales
% y Ab \= no para pintar la parte de abajo
%
dibujaTriangulo(N, SpcIni, Ab):- 
      SpcTr is N*2
   ,  SpcTr2 is SpcTr + 2
   ,  SpcTr3 is SpcTr2 + 2
   ,  Spc2 is SpcIni - 1
   ,  Spc3 is SpcIni - 2
   ,  spcs(SpcIni) , write('/')
   ,  spcs(SpcTr)  , write('\\\n')
	,  spcs(Spc2)   , write('/')
	,  spcs(SpcTr2) , write('\\\n')
   ,  spcs(Spc3)   , write('o')
   ,  (  (Ab = no) -> 
            repiteDib(SpcTr3, '-')
         ;(
				   write('-/') 
				,  spcs(SpcTr)
            ,  write('\\-')
			)
		)
   ,  write('o\n').
				 

%
% Dibuja todo el arbol de forma recursiva con tama�o Tot, y SpcIni 
% espacios iniciales. N es el �ndice que controla el nivel de recursi�n
% y debe comenzar en 1.
%
dibujaArbol(Tot, SpcIni, N):- 
      N >= Tot
   ,  Spc1 is SpcIni - 1
   ,  SpcT is Tot + 3
   ,  dibujaTriangulo(N, Spc1, no)
   ,  dibujaTronco(SpcT, Tot).
dibujaArbol(Tot, SpcIni, N):- 
      Spc1 is SpcIni - 1
   ,  N1 is N + 1
   ,  dibujaTriangulo(N, Spc1, si)
   ,  dibujaArbol(Tot, Spc1, N1).

%
% Predicado principal para dibujar el �rbol
%
xmas(N):- 
      N >= 1
   ,  SpcIni is N + 3
   ,  spcs(SpcIni)
   ,  write('/\\\n')
   ,  dibujaArbol(N, SpcIni, 1).
                 







