%%
%%
repeatNChar(0, _).
repeatNChar(N, Char):-
	   write(Char)
	,  N1 is N-1
	,  repeatNChar(N1, Char).

%%
%%
drawNTablets(XA, X, 1):-
	   XA1 is XA+1
   ,  XA2 is XA+2
   ,  BAR is 5*X-1
	,  repeatNChar(XA, ' ')       , write('\\\\')
	,  repeatNChar(X, '\'\\__\\') , nl
	,  repeatNChar(XA1, ' ')      , write('\\\\')
	,  repeatNChar(X, '/   \\')   , nl
	,  repeatNChar(XA2, ' ')      , write('\\|')
	,  repeatNChar(BAR, '_')      , write('|')
   ,  nl.
drawNTablets(XA, X, Y):-
	   Y1 is Y-1
   ,  XA1 is XA+1
   ,  XA2 is XA+2
   ,  repeatNChar(XA, ' ')       , write('\\\\')
	,  repeatNChar(X, '\'\\__\\') , nl
	,  repeatNChar(XA1, ' ')      , write('\\\\')
	,  repeatNChar(X, '/ __\\')   , nl
   ,	drawNTablets(XA2, X, Y1).

%%
%%
chocolate(X,Y):-
	% First tablet
	   X >= 1
   ,  Y >= 2
   ,	repeatNChar(X, '  ___')   , nl
	,  write('.')
   ,  repeatNChar(X, '\'\\__\\'), nl
   ,  write('|\\')
   ,  repeatNChar(X, '/ __\\')  , nl
	,  Y1 is Y-1
   ,	drawNTablets(1, X, Y1).
