%%%%%%%%%%%%%%%%%%%%%%%
% HECHOS
%%%%%%%%%%%%%%%%%%%%%%%

% Los objetos
%
objeto(0, piedra).
objeto(1, papel).
objeto(2, tijera).

% Qué objeto gana a qué objeto
%
ganar(piedra, tijera).
ganar(tijera, papel).
ganar(papel, piedra).

%%%%%%%%%%%%%%%%%%%%%%%
% REGLAS
%%%%%%%%%%%%%%%%%%%%%%%

% Analizamos quien gana
%
quiengana(X, X):-
	   writeln('Empatamos!').
quiengana(X, Obj):- 
	   ganar(X, Obj)
   ,	writeln('Tu ganas!\n').
quiengana(X, Obj):-
	   ganar(Obj, X)
   ,	writeln('Yo gano!\n').

% Regla para lanzar 1 jugada
%
jugada(X) :- 
      maplist(write, ['Tu juegas con ', X, '\n'])
   ,  Y is random(3)
   ,  objeto(Y, Obj)
   ,  maplist(write, ['Yo juego con ', Obj, '\n'])
   ,  quiengana(X, Obj).
