%
% Repite un mismo dibujo Dib (en texto) N veces
%
repiteDib(N,  _) :- N < 1.
repiteDib(N,Dib) :-
      write(Dib)
   ,  N1 is N-1
   ,  repiteDib(N1,Dib).

%
% Alias de repiteDib para pone N espacios
%
spcs(N):-repiteDib(N,' ').

%
%  Repite N veces el dibujo Dib, separando cada repetici�n
%  con un n�mero Nspc de car�cteres Spc en medio.
%
dibujoEspaciado(N,  _,   _,  _) :- N < 1.
dibujoEspaciado(N,Dib,Nspc,Spc) :-
      write(Dib)
   ,  repiteDib(Nspc, Spc)
   ,  N1 is N-1
   ,  dibujoEspaciado(N1,Dib,Nspc,Spc).

%
% Dibuja el tronco de las velas de longitud N, con Ini espacios
% iniciales hasta la primera vela, y A espacios entre velas
%
dibujaTroncoVelas(  _,_,N) :- N < 1.
dibujaTroncoVelas(Ini,A,N) :- 
      spcs(Ini)
   ,  N1 is N-1
   ,  dibujoEspaciado(5,'||',A,' ')
   ,  write('\n')
   ,  dibujaTroncoVelas(Ini,A,N1).

%
% Dibuja las velas de la tarta, con A espacios entre ellas
%
dibujaVelas(A) :- 
      Ini is A / 2
   ,  spcs(Ini)
   ,  dibujoEspaciado(5,'/\\',A,' ')
   ,  write('\n')
   ,  spcs(Ini)
   ,  dibujoEspaciado(5,'\\/',A,' ')
   ,  write('\n')
   ,  dibujaTroncoVelas(Ini,A,A).

%
% Dibuja el centro de una l�nea de la tarta que contiene rombos, con
% N=tama�o interior del rombo + 2, Med= n�de caracteres 'o' entre
% rombos, St = caracter inicial del rombo, End= caracter de cierre del
% rombo y Vez = n� de rombos a dibujar
%
dibujaCentroLineaRombos(_,  _, _,  _,Vez) :- Vez < 1.
dibujaCentroLineaRombos(N,Med,St,End,Vez) :-
      write(St)
   ,  N1 is N-2
   ,  repiteDib(N1,'X')
   ,  write(End)
   ,  (  (  Vez>1
         ,  repiteDib(Med,'o')
         );
         true
      )
   ,  Vez1 is Vez-1
   ,  dibujaCentroLineaRombos(N,Med,St,End,Vez1).

%
% Dibuja una linea que contiene rombos de la tarta, a�adi�ndole los
% car�cteres 'o' necesarios al principio y al final
%
dibujaLineaRombos(N,Ini,Med,St,End) :-
      repiteDib(Ini, 'o')
   ,  dibujaCentroLineaRombos(N,Med,St,End,5)
   ,  repiteDib(Ini, 'o')
   ,  write('\n').

%
% Dibuja las l�neas de rombos de una tarta necesarias y coloca
% los cierres superior e inferior de esos rombos
%
dibujaRombos(N, Ini,   _) :- N < 2 ; Ini < 1.
dibujaRombos(N, Ini, Med) :- 
      Ini1 is Ini-1
   ,  Med1 is Med-2
   ,  N1 is N+2
   ,  dibujaLineaRombos(N, Ini, Med, '/', '\\')
   ,  dibujaRombos(N1, Ini1, Med1)
   ,  dibujaLineaRombos(N, Ini, Med, '\\', '/').

%
% Prepara la informaci�n necesaria a partir del tama�o de la tarta
% y dibuja las l�neas de rombos con el tama�o apropiado
%
dibujaRombos(Tam) :- 
      Tam >= 2
   ,  Ini is Tam - 1
   ,  Med is (Tam-1)*2
   ,  dibujaRombos(2, Ini, Med).

%
% Dibuja la masa de la tarta, tanto las l�neas de masa simple
% como las l�neas que contienen rombos
%
dibujaMasa(N):-  
      Alto is (N-1)*2
   ,  Total is (Alto+2)*5
   ,  repiteDib(Total,'o')
   ,  write('\n')
   ,  dibujaRombos(N)
   ,  repiteDib(Total,'o')
   ,  write('\n').

%
% Dibuja la tarta de tama�o N, velas y masa.
%
cake(N):-
      N >= 2
   ,  Alto is (N-1)*2
   ,  dibujaVelas(Alto)
   ,  dibujaMasa(N).








